import { Controller, Get } from '@nestjs/common';
import { DummyPropertyAssetsService } from './dummy-property-assets.service';

@Controller('dummy-property-assets')
export class DummyPropertyAssetsController {
  constructor(private readonly dummyPropertyAssetsService: DummyPropertyAssetsService) {}
  @Get('getall')
  async findAll() {
    return this.dummyPropertyAssetsService.findAll();
  }
}
