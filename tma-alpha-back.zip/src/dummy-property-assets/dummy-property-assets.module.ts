import { Module } from '@nestjs/common';
import { DummyPropertyAssetsService } from './dummy-property-assets.service';
import { DummyPropertyAssetsController } from './dummy-property-assets.controller';

@Module({
  controllers: [DummyPropertyAssetsController],
  providers: [DummyPropertyAssetsService],
})
export class DummyPropertyAssetsModule {}
